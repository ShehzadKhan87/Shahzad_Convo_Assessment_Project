package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.TablesPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

public class TablesTest extends BaseTest{
	 private TablesPage tablesPage;

	 @BeforeMethod
	 public void setUpTest() {
	     String url = properties.getProperty("baseUrl", "https://the-internet.herokuapp.com") + "/tables"; //adding a fallback URL
	     System.out.println("Navigating to: " + url);
	     
	     driver.get(url);
	     tablesPage = new TablesPage(driver);
	 }

	    @Test(priority = 1)
	    public void testExtractAllCompanyNames() {
	        test = extent.createTest("Extract All Company Names");
	        List<String> companyNames = tablesPage.getCompanyNames();
	        
	        System.out.println("Company Names: " + companyNames);
	        test.info("Extracted Company Names: " + companyNames);
	        
	        Assert.assertFalse(companyNames.isEmpty(), "Company names list is empty!");
	        test.pass("Successfully extracted company names.");
	    }

	    @Test(priority = 2)
	    public void testVerifyCompanyExists() {
	        test = extent.createTest("Verify Company Exists");
	        String companyToCheck = "Doe"; // Update to match table structure

	        List<String> extractedCompanies = tablesPage.getCompanyNames();
	        System.out.println("Extracted Company Names: " + extractedCompanies);
	        test.info("Extracted Companies: " + extractedCompanies);

	        boolean isPresent = extractedCompanies.contains(companyToCheck);

	        if (!isPresent) {
	            test.fail("Company " + companyToCheck + " not found in table! Extracted: " + extractedCompanies);
	        }

	        Assert.assertTrue(isPresent, "Company " + companyToCheck + " not found in the table!");
	        test.pass("Company " + companyToCheck + " is present in the table.");
	    }

	    @Test(priority = 3)
	    public void testExtractColumnData() {
	        test = extent.createTest("Extract Column Data");
	        int columnIndex = 2; // Extract Last Name column (Change this as needed)

	        List<String> columnData = tablesPage.getColumnData(columnIndex);
	        System.out.println("Column Data: " + columnData);
	        test.info("Extracted Column Data: " + columnData);

	        Assert.assertFalse(columnData.isEmpty(), "Column data is empty!");
	        test.pass("Successfully extracted column data.");
	    }

}
