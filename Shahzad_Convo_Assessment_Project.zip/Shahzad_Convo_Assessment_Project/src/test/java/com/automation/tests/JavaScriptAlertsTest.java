package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.JavaScriptAlertsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class JavaScriptAlertsTest extends BaseTest {
	
	private JavaScriptAlertsPage alertsPage;

    @BeforeMethod
    public void setUpTest() {
        driver.get(properties.getProperty("baseUrl") + "/javascript_alerts");
        alertsPage = new JavaScriptAlertsPage(driver);
    }

    @Test(priority = 1)
    public void testSimpleAlert() {
        test = extent.createTest("Handle Simple Alert");
        alertsPage.handleSimpleAlert();
        String result = alertsPage.getResultText();
        Assert.assertEquals(result, "You successfully clicked an alert", "Simple Alert Result Mismatch!");
        test.pass("Simple alert handled successfully.");
    }

    @Test(priority = 2)
    public void testConfirmationAlertOK() {
        test = extent.createTest("Handle Confirmation Alert - OK");
        alertsPage.handleConfirmationAlert(true);
        String result = alertsPage.getResultText();
        Assert.assertEquals(result, "You clicked: Ok", "Confirmation Alert (OK) Result Mismatch!");
        test.pass("Confirmation alert (OK) handled successfully.");
    }

    @Test(priority = 3)
    public void testConfirmationAlertCancel() {
        test = extent.createTest("Handle Confirmation Alert - Cancel");
        alertsPage.handleConfirmationAlert(false);
        String result = alertsPage.getResultText();
        Assert.assertEquals(result, "You clicked: Cancel", "Confirmation Alert (Cancel) Result Mismatch!");
        test.pass("Confirmation alert (Cancel) handled successfully.");
    }

    @Test(priority = 4)
    public void testPromptAlert() {
        test = extent.createTest("Handle Prompt Alert");
        String inputText = "Automation Test";
        alertsPage.handlePromptAlert(inputText);
        String result = alertsPage.getResultText();
        Assert.assertEquals(result, "You entered: " + inputText, "Prompt Alert Result Mismatch!");
        test.pass("Prompt alert handled successfully.");
    }

}
