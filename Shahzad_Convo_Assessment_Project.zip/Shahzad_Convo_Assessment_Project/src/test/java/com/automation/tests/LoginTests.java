package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

	private LoginPage loginPage;

	@BeforeMethod
	public void setUpTest() {
		driver.get(properties.getProperty("baseUrl") + "/login");
		loginPage = new LoginPage(driver);
	}
	
	@DataProvider(name = "loginData")
	public Object[][] getLoginData() {
		return new Object[][] {
			{"tomsmith", "SuperSecretPassword!", true},   // Valid login
			{"invalidUser", "invalidPass", false},        // Invalid login
			{"tomsmith", "WrongPassword!", false},        // Wrong password
			{"", "", false}                               // Empty credentials
		};
	}

	@Test(priority = 1, dataProvider = "loginData")
    public void testLogin(String username, String password, boolean expectedResult) {
        System.out.println("Attempting login with Username: " + username + " | Password: " + password);
        test = extent.createTest("Login Test - User: " + username);

        loginPage.login(username, password);
        loginPage.takeScreenshot("LoginAttempt_" + username); // Save screenshot with username

        boolean actualResult = loginPage.isLoginSuccessful();
        System.out.println("Login success status: " + actualResult);
        test.info("Expected: " + expectedResult + " | Actual: " + actualResult);

        // Assertion for expected login result
        Assert.assertEquals(actualResult, expectedResult, "Login test failed!");

        if (expectedResult) {
            test.pass("Login successful for user: " + username);
        } else {
            test.fail("Login failed as expected for user: " + username);
        }
    }
}
