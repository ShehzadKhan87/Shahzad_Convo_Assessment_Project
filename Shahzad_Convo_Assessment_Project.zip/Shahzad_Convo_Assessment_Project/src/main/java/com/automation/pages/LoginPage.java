package com.automation.pages;

import com.automation.base.BasePage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage{

	// Locators
	private By usernameField = By.id("username");
	private By passwordField = By.id("password");
	private By loginButton = By.cssSelector("button.radius");
	private By errorMessage = By.id("flash");
	private By logoutButton = By.xpath("//a[@href='/logout']");

	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	// Method to perform login
	public void login(String username, String password) {
		enterText(usernameField, username);
		enterText(passwordField, password);
		clickElement(loginButton);
	}

	// Method to check login success
	public boolean isLoginSuccessful() {
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(logoutButton));
	        System.out.println("Logout button detected. Login successful!");
	        return true;
	    } catch (TimeoutException e) {
	        System.out.println("Logout button NOT found after waiting. Login failed.");
	        return false;
	    }
	}

	// Method to get error message
	public String getErrorMessage() {
		return getElementText(errorMessage);
	}

}