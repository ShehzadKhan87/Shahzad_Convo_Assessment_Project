package com.automation.pages;

import com.automation.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.ArrayList;
import java.util.List;


public class TablesPage extends BasePage{
	private By tableRows = By.xpath("//table[@id='table1']//tbody/tr");
    private By tableColumns = By.xpath("//table[@id='table1']//thead/tr/th");

	public TablesPage(WebDriver driver) {
		super(driver);
	}
	 // 1. Extract & Print All Company Names
	public List<String> getCompanyNames() {
	    List<WebElement> companyCells = driver.findElements(By.xpath("//table[@id='table1']//tr/td[1]"));
	    List<String> companyNames = new ArrayList<>();
	    
	    for (WebElement cell : companyCells) {
	        companyNames.add(cell.getText().trim()); // ✅ Ensure trimming whitespace
	    }

	    System.out.println("📋 Found Company Names: " + companyNames);
	    return companyNames;
	}

    // 2. Verify if a Specific Company Exists
    public boolean isCompanyPresent(String companyName) {
        List<String> companyNames = getCompanyNames();
        return companyNames.contains(companyName);
    }

    // 3. Generic Method to Extract Any Column Data
    public List<String> getColumnData(int columnIndex) {
        List<String> columnData = new ArrayList<>();
        List<WebElement> rows = driver.findElements(tableRows);

        for (WebElement row : rows) {
            WebElement cell = row.findElement(By.xpath("./td[" + columnIndex + "]"));
            columnData.add(cell.getText());
        }
        return columnData;
    }
}
