package com.automation.pages;

import com.automation.base.BasePage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class JavaScriptAlertsPage extends BasePage {
	
    private By jsAlertButton = By.xpath("//button[text()='Click for JS Alert']");
    private By jsConfirmButton = By.xpath("//button[text()='Click for JS Confirm']");
    private By jsPromptButton = By.xpath("//button[text()='Click for JS Prompt']");
    private By resultText = By.id("result");

	public JavaScriptAlertsPage(WebDriver driver) {
		super(driver);
	}
	
	// Handling Simple Alert (Click OK)
    public void handleSimpleAlert() {
        driver.findElement(jsAlertButton).click();
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    // Handling Confirmation Alert (Click OK or Cancel)
    public void handleConfirmationAlert(boolean accept) {
        driver.findElement(jsConfirmButton).click();
        Alert alert = driver.switchTo().alert();
        if (accept) {
            alert.accept();
        } else {
            alert.dismiss();
        }
    }

    // Handling Prompt Alert (Enter text and Click OK)
    public void handlePromptAlert(String inputText) {
        driver.findElement(jsPromptButton).click();
        Alert alert = driver.switchTo().alert();
        alert.sendKeys(inputText);
        alert.accept();
    }

    // Getting Result Text
    public String getResultText() {
        return driver.findElement(resultText).getText();
    }
	

}
