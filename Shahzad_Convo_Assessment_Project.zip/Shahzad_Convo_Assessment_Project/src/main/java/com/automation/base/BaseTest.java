package com.automation.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class BaseTest {
	protected WebDriver driver;
	protected Properties properties;
	private static final Logger logger = LogManager.getLogger(BaseTest.class);

	// Extent Reports setup
	protected static ExtentReports extent;
	protected ExtentTest test; 

	@BeforeSuite
	public void setupReport() {
		ExtentSparkReporter spark = new ExtentSparkReporter("reports/ExtentReport.html");
		extent = new ExtentReports();
		extent.attachReporter(spark);
	}

	@BeforeMethod
	@Parameters("browser")
	public void setup(@Optional("chrome") String browser) {
	    if (properties == null) { // Ensure properties are loaded only once
	        loadProperties();
	    }

	    test = extent.createTest("Test Execution"); //Initialize Extent Report test

	    switch (browser.toLowerCase()) {
	        case "firefox":
	            WebDriverManager.firefoxdriver().setup();
	            driver = new org.openqa.selenium.firefox.FirefoxDriver();
	            break;
	        case "edge":
	            WebDriverManager.edgedriver().setup();
	            driver = new org.openqa.selenium.edge.EdgeDriver();
	            break;
	        default:
	            WebDriverManager.chromedriver().setup();
	            driver = new ChromeDriver();
	            break;
	    }

	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    logger.info("Browser launched: " + browser);
	}

	@AfterMethod
	public void tearDown(ITestResult result) {
		if (test != null) { // Ensuring `test` is not null before logging results
			if (result.getStatus() == ITestResult.FAILURE) {
				test.fail("Test Failed: " + result.getName());
			} else if (result.getStatus() == ITestResult.SUCCESS) {
				test.pass("Test Passed: " + result.getName());
			}
		}

		if (driver != null) {
			driver.quit();
			logger.info("Browser closed.");
		}
	}

	@AfterSuite
	public void tearDownReport() {
		extent.flush();
	}

	private void loadProperties() {
	    properties = new Properties();
	    try {
	        FileInputStream file = new FileInputStream("C:\\Users\\shahzad.khan\\eclipse-workspace\\Shahzad_Convo_Assessment_Project\\src\\test\\java\\com\\automation\\resources\\config.properties");
	        properties.load(file);
	        file.close();
	    } catch (IOException e) {
	        logger.error("Failed to load config.properties file: " + e.getMessage());
	    }
	}

	public WebDriver getDriver() {
		return driver;
	}

}
